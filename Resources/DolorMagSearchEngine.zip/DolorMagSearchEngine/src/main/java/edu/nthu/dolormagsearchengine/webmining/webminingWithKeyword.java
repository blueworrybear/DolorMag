/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.nthu.dolormagsearchengine.webmining;

import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.http.json.JsonHttpRequest;
import com.google.api.client.http.json.JsonHttpRequestInitializer;
import com.google.api.client.json.jackson.JacksonFactory;
import com.google.api.services.customsearch.Customsearch;
import com.google.api.services.customsearch.CustomsearchRequest;
import com.google.api.services.customsearch.Customsearch.Cse.List;
import com.google.api.services.customsearch.model.Result;
import com.google.api.services.customsearch.model.Search;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author bear
 */
public class webminingWithKeyword {
    String query;
    
    public webminingWithKeyword(){
        
    }
    
    public void setKey(String key){
        this.query = key;
    }
    
    public ArrayList<String> show() throws IOException{
        
        Customsearch cust = Customsearch.builder(new NetHttpTransport(), new JacksonFactory()).setApplicationName("DolorMag").setJsonHttpRequestInitializer(new JsonHttpRequestInitializer() {

            @Override
            public void initialize(JsonHttpRequest request) throws IOException {
                CustomsearchRequest tasksRequest = (CustomsearchRequest) request;
                tasksRequest.setKey("AIzaSyDUrUIyiXNnx1U-s9DXsMphanA6_sLsnbM");
            }
        }).build();
        
        Customsearch.Cse.List list = cust.cse().list(this.query);
        list.setCx("002943815058755975153:qd7k94cdok8");
        
        Search result = list.execute();
        
        java.util.List<Result> items = result.getItems();
        Iterator it = items.iterator();
        
        ArrayList<String> links = new ArrayList<String>();
        
        while(it.hasNext()){
            Result re = (Result) it.next();
            links.add(re.getLink());
        }
        
        return links;
    }
}
