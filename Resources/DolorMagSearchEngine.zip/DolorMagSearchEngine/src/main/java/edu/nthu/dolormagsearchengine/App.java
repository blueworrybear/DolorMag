package edu.nthu.dolormagsearchengine;

import edu.nthu.dolormagsearchengine.webmining.webminingWithKeyword;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Hello world!
 *
 */

public class App 
{
    public static void main( String[] args ) throws IOException
    {
        System.out.println( "Hello World!" );
        webminingWithKeyword web = new webminingWithKeyword();
        web.setKey("bear");
        ArrayList<String> list = web.show();
        Iterator it = list.iterator();
        
        while(it.hasNext()){
            String link = (String) it.next();
            System.out.println(link);
        }
    }
}
